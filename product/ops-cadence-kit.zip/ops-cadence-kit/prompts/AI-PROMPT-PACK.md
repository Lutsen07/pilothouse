# AI Prompt Pack (Grok / ChatGPT / Claude)

Paste after your context. Always include: channel, SKU type, team size.

## P1 — Notes to SOP

```
You are an operations editor. Turn the notes below into a one-page SOP.
Rules: numbered steps, one owner, one "done when" line, one explicit STOP.
No filler. Max 12 steps. Use the same style as: short imperative sentences.
NOTES:
```

## P2 — Exception to root cause

```
Here is an exception log row. Give: (1) most likely root cause, (2) which SOP should own it,
(3) a 1-week experiment to prove the fix. Be concrete.
ROW:
```

## P3 — Vendor chase email

```
Write a 5-sentence vendor chase email. Firm, not rude. Ask for a date not a status.
Include cancel date. PO details:
```

## P4 — Scorecard narrative

```
Here are 4 weeks of scorecard numbers. In 8 bullets: what improved, what decayed,
the single constraint. No pep talk.
DATA:
```

## P5 — New channel listing QA

```
Generate a listing QA checklist for [channel] given we sell [product type].
Must include handling time, weight, and first-image rule. 8–12 checks.
```
