# 14-Day Install Calendar

Goal: by day 14 you have a Monday meeting that actually runs, an exception log with at least 5 rows, and 3 live SOPs.

## Week 1 — See the work

- **Day 1:** Create a shared folder. Copy all CSVs to Sheets. Name the tab “Ops Cadence.”
- **Day 2:** Fill last week’s scorecard from memory (don’t wait for perfect data).
- **Day 3:** Stand up the exception log. Add every fire from the last 7 days.
- **Day 4:** Tag each exception: `stock` `vendor` `listing` `ship` `return` `other`.
- **Day 5:** Count tags. Circle the #1 tag. That is next week’s SOP.
- **Day 6:** Rest. Do not “fix the warehouse” today.
- **Day 7:** 20-minute Friday close: scorecard + 3 bullets (keep / kill / try).

## Week 2 — Install three SOPs

- **Day 8:** Publish SOP-01 Receiving (or adapt). One owner. One “done” definition.
- **Day 9:** Publish SOP-06 Returns.
- **Day 10:** Publish SOP-07 Vendor chase.
- **Day 11:** Walk one new hire or contractor through all three. Time it. Cut any step over 2 minutes of explanation.
- **Day 12:** Run Monday scorecard for real (this week’s numbers).
- **Day 13:** Exception log review — close anything older than 14 days or assign a date.
- **Day 14:** Record a 5-minute loom of “how we run Monday.” That is your training.

If you skip days, do not restart. Resume the next unfinished day.
