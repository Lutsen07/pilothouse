# Exception Log

An exception is any event that stole **>15 minutes** and was not on the SOP.

## Rules

- One row per incident. No novels.
- Tag: `stock` `vendor` `listing` `ship` `return` `other`
- Status: `open` `watching` `sop-written` `closed`
- If the same tag hits 3 times in 14 days → write or fix an SOP that week.

## Columns (see templates/exceptions.csv)

`date, channel, sku, tag, minutes_lost, what_broke, owner, status, sop_id`

## Friday 10-minute review

1. Sort by tag count.
2. Close anything with a live SOP and zero repeats.
3. Assign one open row an SOP id from `sops/`.
