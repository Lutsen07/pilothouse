# The Ops Cadence Kit

Welcome. This kit is a **weekly operating rhythm**, not a 200-page binder. Install it in 14 days using `14-DAY-INSTALL.md`.

## What’s inside

| File | Use |
|------|-----|
| `14-DAY-INSTALL.md` | Day-by-day setup so this doesn’t die in Downloads |
| `SCORECARD.md` | Monday 20-minute ops review |
| `EXCEPTION-LOG.md` | One place for repeating fires |
| `sops/` | 12 copy-paste SOPs |
| `templates/` | CSV scorecard, exceptions, vendor chase |
| `prompts/AI-PROMPT-PACK.md` | Prompts to write more SOPs from messy notes |

## How to use (first hour)

1. Copy `templates/scorecard.csv` into Google Sheets or Excel.
2. Run this week’s Monday scorecard (`SCORECARD.md`).
3. Log every fire that wasted >15 minutes in `templates/exceptions.csv`.
4. Pick the **top exception** Friday and write or adapt one SOP from `sops/`.

Owner: you. Pilothouse does not log into your store.
