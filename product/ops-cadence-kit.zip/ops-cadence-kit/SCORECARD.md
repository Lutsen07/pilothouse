# Monday Ops Scorecard (20 minutes)

Run every Monday before noon local. One owner. Camera off is fine.

## Inputs (grab these first)

- Units received last 7 days
- Units shipped last 7 days
- Open orders older than promise date
- SKUs at or below reorder point
- Open returns / claims
- Vendor POs late

## Score (0–2 each)

| Line | 0 | 1 | 2 |
|------|---|---|---|
| Promise hit rate | <90% | 90–97% | ≥98% |
| Late POs | 5+ | 1–4 | 0 |
| Stockouts (active SKUs) | 5+ | 1–4 | 0 |
| Returns without reason code | >20% | 5–20% | <5% |
| Exceptions open >14 days | 5+ | 1–4 | 0 |

**Max 10.** Below 6 = Friday SOP session is mandatory.

## Script

1. Read last week’s three bullets.
2. Fill numbers. No debate until numbers are in.
3. Pick **one** exception to kill this week (not five).
4. Write this week’s three bullets: Keep / Kill / Try.
5. End at 20:00 on the clock.

Use `templates/scorecard.csv` to store history.
