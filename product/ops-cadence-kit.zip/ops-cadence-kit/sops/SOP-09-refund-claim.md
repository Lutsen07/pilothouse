# SOP-09 Refund / claim

1. Decide in 1 business day: refund, replace, or deny (with policy cite).
2. If carrier damage: open claim same day with photo + weight.
3. Never both refund and replace without a note in the exception log.
4. Tag `return` or `ship`.
5. Weekly: refund $ / GMV. If >3%, Friday SOP session on listing or pack.
