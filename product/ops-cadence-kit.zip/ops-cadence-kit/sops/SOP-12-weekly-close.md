# SOP-12 Weekly close (Friday, 25 minutes)

1. Fill scorecard if Monday was skipped (shame is allowed, skipping twice is not).
2. Exception log: close or date every open row.
3. Cash: landed cost surprises this week (freight, claims, rush).
4. People: one sentence on who was the bottleneck.
5. Write next Monday’s agenda (3 bullets max).
6. Back up the sheet (Download → Excel, drop in the folder).
