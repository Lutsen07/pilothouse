# SOP-04 Pick / pack

**Done when:** Order is sealed, label on, photo in folder (optional for claims).

1. Pick by location order, not by SKU name.
2. Check SKU and qty against the slip at the pack table — not at the bin.
3. Insert pack slip / thank-you if you use one.
4. Weigh. If weight is >15% off expected, stop and re-pick.
5. Apply label. Scan-out or mark shipped the same hour.
