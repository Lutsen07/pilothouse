# SOP-02 Putaway

**Done when:** Location in the system matches the physical bin.

1. Take only one SKU per trip.
2. Scan or write bin ID before placing units.
3. FIFO: older lot to the front.
4. If bin is full, use overflow bin and note it on the scorecard sheet.
5. Confirm system location = bin ID.
