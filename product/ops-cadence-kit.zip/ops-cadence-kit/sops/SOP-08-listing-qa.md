# SOP-08 Listing QA

Run before any new SKU goes live and after any return tagged `not_as_described`.

1. Title contains brand + product + 1 attribute (size/color).
2. First image: white or consistent background, no text.
3. Specs match the pack slip (weight, dimensions, pack qty).
4. Policy: handling time matches real pick/pack (SOP-04).
5. Checklist signed in the sheet. No “we’ll fix photos later.”
