# SOP-05 Ship exception

Use when carrier pickup is missed, address fails, or label voids.

1. Freeze the order in the channel.
2. Tag exception `ship`. Record minutes.
3. Buyer message template: “Your order is packed. We’re reprinting the label and it will move within 1 business day.”
4. Reprint. Do not reuse a voided label file.
5. If delay >48h: offer cancel or upgrade shipping. Log the choice.
