# SOP-10 Stockout decision

When on-hand hits reorder point:

1. Check open PO and inbound date.
2. If inbound > lead time: raise listing handling time or pause the SKU.
3. Do not leave “in stock” with 0 pickable units.
4. Log `stock`. Record lost-order estimate if you can.
5. Reorder using last 4 weeks demand × lead time + 1 week buffer (start simple).
