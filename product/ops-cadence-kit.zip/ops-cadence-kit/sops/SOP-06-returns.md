# SOP-06 Returns

**Done when:** Reason code is set and unit is restock, refurb, or scrap.

1. Issue RMA number = order id + `-R`.
2. Inspect: sellable / refurb / scrap. Photo if over $25 landed.
3. Reason codes only: `damaged_in_transit` `wrong_item` `not_as_described` `buyer_remorse` `other`.
4. Restock sellable same day. Scrap is a `stock` exception if >2% of that SKU/month.
5. Close the RMA. Never leave “pending” over 7 days.
