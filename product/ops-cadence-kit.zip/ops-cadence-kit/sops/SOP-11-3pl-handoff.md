# SOP-11 3PL / helper handoff

Use when someone else picks, or you send a batch to a 3PL.

1. One SKU mapping file. No verbal “it’s the blue one.”
2. Send: SKU, barcode, pack qty, weight, photo.
3. Confirm first 5 orders with photo review.
4. Daily: 3PL on-hand vs your channel. Variance = freeze that SKU.
5. Exception tag `stock` or `ship`.
