# SOP-03 Cycle count

**Cadence:** 5–10 SKUs every Friday, ABC: A weekly, B monthly, C quarterly.

1. Print or filter the count list. No counting from memory.
2. Count twice if first pass ≠ system.
3. If still ≠ system: freeze sales on that SKU until researched.
4. Log exception with minutes and likely cause (`stock`).
5. Adjust system only after a second person (or a photo + timestamp) confirms.
