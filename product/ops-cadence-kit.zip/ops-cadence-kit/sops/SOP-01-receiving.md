# SOP-01 Receiving

**Owner:** Warehouse / founder  
**Done when:** Units are counted, variance logged, putaway ticket created.

1. Photograph the closed carton and packing list.
2. Open PO. Confirm SKU and expected qty.
3. Count sellable units only. Quarantine damage in a red bin.
4. If variance ≠ 0: log exception (`vendor` or `stock`) before putaway.
5. Label carton with receive date + PO #.
6. Create putaway task (SOP-02).
7. Update on-hand in the channel of record the same day.

**Stop:** Do not put away a variance carton.
