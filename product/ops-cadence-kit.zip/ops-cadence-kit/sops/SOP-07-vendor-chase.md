# SOP-07 Vendor chase

**Trigger:** PO confirm date missed by 1 business day.

1. Open `templates/vendor-chase.csv`. Add row if missing.
2. Message 1 (day +1): “Confirm ship date for PO #__. Need a date, not a status.”
3. Message 2 (day +3): CC accounts payable. “We will cancel remaining qty on [date] unless we have a tracking number.”
4. Message 3 (day +5): Cancel or split PO. Log exception `vendor`.
5. After 2 late POs in 60 days: move vendor to “watch” and raise safety stock one cycle.
